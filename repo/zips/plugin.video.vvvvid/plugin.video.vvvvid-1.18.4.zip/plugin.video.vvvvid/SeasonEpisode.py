
class SeasonEpisode():
    show_id = ''
    season_id = ''
    manifest = ''
    title = ''
    thumb = ''
    stream_type = ''