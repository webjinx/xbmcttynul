

class ElementChannel():
    title = ''
    thumb = ''
    show_id = 0
    id=0
    ondemand_type = 0
    show_type = 0

    def __init__(self, id,show_id,title, thumb, ondemand_type, show_type):
        self.title = title
        self.thumb = thumb
        self.show_id = show_id
        self.id = id
        self.ondemand_type = ondemand_type
        self.show_type = show_type

    
    
    
    