
class ItemPlayableSeason():
    id = ''
    show_id=''
    season_id=''
    episodes = []
    title = ''
