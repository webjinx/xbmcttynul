# La7-La7d Kodi plugin
Live Streaming La7, News and Weather, Replay the last week, Programs on-demand (italian television)


### Changelog

2.0.0 (2019-02-17)
- fixed Live stream on Kodi18
- added InputStream Adaptive in the required add-on
- improved logfile about InputStream management
- fixed TG La7 on Rivedi La7
- removed TG Cronache
- fixed TG La7d randomly without plot

1.8.0 (2018-08-10)
- automatic activation of add-on InputStream Adaptive
- removed the filtering of episodes where not necessary

1.7.7 (2018-08-08)
- re-enabled La7 live streaming by added support for adaptive streaming (by sowdust)

1.7.6 (2018-08-01)
- added Omnibus News
- filter out Omnibus News and TG Cronache from Program on demand results

1.7.5 (2018-04-21)
- added some programs thumb
- removed unused var
- updated GNU GPL License to last version 3.0

1.7.4 (2018-04-20)
- video_programma() refactoring

1.7.3 (2018-04-19)
- removed "Requests" library
- play_video() refactoring
- avoid duplication of episodes when "switchBtn archivio" class is removed from programs page

1.7.2 (2018-04-18)
- code refactoring
- video embedded in iframe on Rivedi section is playable
- programs without episodes do not force on returning to the main menu
- images updated
- moved deprecated changelog.txt to addon.xml

1.7.1 (2018-04-14)
- Version for Kodi repository
- revised code by rework/remove some functions
- removed deprecated iconImage kwarg
- updated Fanart
- revised except type and added new except
- corrected language identification
- moved strings.po to the resource.language folders
- reversed weekdays on Replay sections
- added control and warning to the user for unavailable videos
- added new on-demand programs
  Bianco e Nero
  Bellezze in Bicicletta
  Special Guest
  Eccezionale Veramente 2016
  Eccezionale Veramente 2017
  L'ora della salute
  Missione Natura
  Italian Fashion Show
  La mala educaxxxion (new page)
  Video non catalogati (Film e Serie)
  Video non catalogati (Doc e Altro)

1.7.0 (2018-04-05)
- separated the TG La7 Cronache from TG La7
- removed duplicated episodes on Josephine Ange Gardien

1.6.0 (2018-04-03)
- new section News and Weather (Tg La7, Tg La7d, Tg Cronache, Meteo)

1.5.3 (2018-03-29)
- added fanart and thumbnails to all pages of the addon

1.5.2 (2018-03-28)
- added fanart
- added sections thumbnail

1.5.1 (2018-03-27)
- removed Next page link when not necessary 
  (this also solves the problem of duplicating episodes on some Programs)
- L'Ispettore Barnaby episodes duplication fix

1.5.0 (2018-03-26)
- added program broadcast date for all programs

1.4.0 (2018-03-22)
- now the videos in the Week section of all programs are listed
  (this also solves the problem that the last episode sometimes did not appear)
- manually added the Program Artedi

1.3.0 (2018-03-04)
- new icon La7/La7d
- scrap of old on demand programs index page
- removed duplicated Programs
- Fix for random missing tag "p" on Replay La7 and Replay La7d 
- Program mamma mia che settimana fix
- Program se stasera sono qui fix
- Program chi sceglie la seconda casa fix

1.2.0 (2018-02-27)
- added La7d Replay
- added display of the seventh day on La7 Replay and La7d Replay

1.1.1 (2018-02-27)
- bugfix for program without Thumbnail

1.1.0 (2018-02-26)
- added La7d On Demand Programs
- scrap of new on demand programs index page
- Program Faccia a Faccia fix
- removed Program directory letter group

1.0.0 (2017-12-02)
- bugfix

0.0.9 (2017-09-23)
- re-added live streaming (by sowdust)
- bugfix

0.0.8 (2017-09-11)
- fixed TG link
- now episodes of shows are all visible

0.0.7 (2016-09-17)
- bugfix to site change

0.0.6 (2016-06-03)
- bugfix to site change

0.0.5 (2016-04-24)
- bugfix

0.0.4 (2016-04-07)
- fixed lib on android

0.0.3 (2016-03-08)
- added localized language

0.0.2 (2016-03-08)
- bugfix
- add live streaming

0.0.1 (2016-03-07)
- Initial Release

