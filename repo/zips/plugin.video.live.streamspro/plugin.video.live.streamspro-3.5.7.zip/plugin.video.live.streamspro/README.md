![](https://i.imgur.com/c7Ks3m8.png)

**Live Streams Pro +**, shamelessly a fork of a fork, livestreams originally developed by **divingmule** first and **Shani** later.
This can just do what Live Streams Pro could do, but with some new cool features, they are all listed in [Wiki Homepage](https://github.com/cttynul/plugin.video.live.streamspro/wiki)

If you are a developer **don't fork and rename** but, please, **open a [pull request](https://github.com/cttynul/plugin.video.live.streamspro/pulls)** if everything is working like a charm it will be accepted and I will credit you! 

This fork has been testend on **Kodi Leia 18.2**, btw it should work in any release (Isengard 15+), planning to make it work with **Python 3**, if you wanna help you're welcome.

### Links
* Can't understand anything? [Check Wiki](https://github.com/cttynul/plugin.video.live.streamspro/wiki)
* Something isn't working? [Let me know](https://github.com/cttynul/plugin.video.live.streamspro/issues)

### DMCA
Live Streams Pro + **doesn't contain or provide anything**! And it isn't developed with the prupose of violating any copyright, LSP+ works exactly like a video player, complaining about it cause it could make you watch pirated content is like complaining about _insert any video player here_ cause it could do the same. 

Any copyright infringement wil be user fault, not mine. If you legally buy a gun and you use it to rob a bank whose fault is that? Seller or yours?

No assistance will be given if you're using LSP+ for illegal purposes. Please respect copyrighted work and any laws applicable to yourself whilst using LSP+.

### License
Published under **GNU General Public License V2** as original projects developed by Shani and divingmule were, [here](https://github.com/cttynul/plugin.video.live.streamspro/blob/master/LICENSE.txt) something about license.
